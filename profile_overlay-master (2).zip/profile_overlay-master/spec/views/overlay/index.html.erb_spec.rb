require 'rails_helper'

RSpec.describe "overlay/index.html.erb", type: :view do
end
