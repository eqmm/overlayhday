# Profile Overlay

[![Build Status](https://travis-ci.org/lalusaud/profile_overlay.svg)](https://travis-ci.org/lalusaud/profile_overlay)
[![Code Climate](https://codeclimate.com/github/lalusaud/profile_overlay/badges/gpa.svg)](https://codeclimate.com/github/lalusaud/profile_overlay)
[![Test Coverage](https://codeclimate.com/github/lalusaud/profile_overlay/badges/coverage.svg)](https://codeclimate.com/github/lalusaud/profile_overlay/coverage)

An application to update profile picture for facebook.com
